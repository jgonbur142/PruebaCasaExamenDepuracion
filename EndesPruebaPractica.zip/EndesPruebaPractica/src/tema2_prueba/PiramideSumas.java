package tema2_prueba;

import java.util.Scanner;

public class PiramideSumas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String resp;

        do {
            int numero = leerEntero(sc, "Introduzca un número: "); //JGB20251031 faltaba un (;) al final de la linea
            if (numero < 0) {
            	numero = leerEntero(sc,"**Valor no válido** Introduzca un número entero"); //JGB20251031 añado un if para comprobar en concreto si el número introducido es menor que 0
            }
            while (numero < 0 || numero > 20) { //JGB20251031 cambio el && por || para que sí que vuelva a hacer la pregunta cuando un numero no sea valido
                numero = leerEntero(sc, "**Valor fuera de rango** Introduzca un número entre 0 y 20: ");
            }

            System.out.println("\nSu pirámide de sumas es la siguiente:\n" + piramide(numero));

            System.out.print("¿Quiere hacer otra pirámide? (s/n) ");
            resp = sc.next().trim().toUpperCase(); //JGB20251031 sobraba "String" al principio de la linea, ya esta la variable inicializada mas arriba en el codigo

        } while (resp.equalsIgnoreCase("S"));//JGB20251031 faltaba un ")" para cerrar correctamente la linea, ademas, he añadido el ignoreCase para poder introducir S o s sin problemas.

        borrarConsola();
        System.out.println("¡¡¡PROGRAMA FINALIZADO!!!");
        
        sc.close();
        
        
    }
  /* esto esta comentado porque es de la plantilla hecha en el 2.5
     public static void borrarConsola() {
   
		for (int i = 0; i < 25; i++) {
		System.out.println();
		}
	}
   */
    private static int leerEntero(Scanner sc, String mensaje) {
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.print("**Valor no válido** Introduzca un número entero: ");
            sc.next();
        }
        return sc.nextInt();
    }

    public static void borrarConsola() {
        for (int i = 0; i < 50; i++) { //JGB20251031 habia una (,) en lugar de (;) dentro del for
            System.out.println();
        }
    }

    public static String piramide(int num) {
        String res = "";
        int n = num;

        while (n >= 0) { //JGB20251031 cambio (<=) por (>=)
            int cont = 1;
            int total = 0;
            res += n + " => 0 ";

            if (cont <= n) //JGB20251031 cambio el while por un if
                res += "+ " + cont + " "; //JGB20251031 sé que cambiando la lógica de esta parte se puede corregir la piramide, pero no encuentro la solucion
                total += cont;
                cont += 1;

            if (n != 0) {
                res += "= " + total;
            }

            res += "\n";
            n -= 1;
        }

        return res;//JGB20251031 he cambiado "resultado" por "res", la variable esta declarada con ese nombre
    }

}
